import Foundation
import WidgetKit

enum CheckInStore {
    // In Xcode, replace this with your own App Group identifier and enable that
    // same App Group for BOTH the main app target and the widget extension.
    static let appGroup = "group.com.example.SmokeFreeCheckIn"
    static let checkedInKey = "checkedInDates"

    static var defaults: UserDefaults {
        UserDefaults(suiteName: appGroup) ?? .standard
    }

    static var checkedInDates: Set<String> {
        get { Set(defaults.stringArray(forKey: checkedInKey) ?? []) }
        set { defaults.set(Array(newValue), forKey: checkedInKey) }
    }

    static func dateKey(for date: Date = Date()) -> String {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.timeZone = .current
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }

    static var checkedInToday: Bool {
        checkedInDates.contains(dateKey())
    }

    static var streak: Int {
        let dates = checkedInDates
        let calendar = Calendar.current
        var day = calendar.startOfDay(for: Date())
        if !dates.contains(dateKey(for: day)) {
            guard let yesterday = calendar.date(byAdding: .day, value: -1, to: day),
                  dates.contains(dateKey(for: yesterday)) else { return 0 }
            day = yesterday
        }

        var count = 0
        while dates.contains(dateKey(for: day)) {
            count += 1
            guard let previous = calendar.date(byAdding: .day, value: -1, to: day) else { break }
            day = previous
        }
        return count
    }

    @discardableResult
    static func checkInToday() -> Bool {
        guard !checkedInToday else { return false }
        var dates = checkedInDates
        dates.insert(dateKey())
        checkedInDates = dates
        WidgetCenter.shared.reloadAllTimelines()
        return true
    }
}
