import SwiftUI
import WidgetKit

struct CheckInView: View {
    @State private var refresh = false

    var body: some View {
        let _ = refresh
        ZStack {
            LinearGradient(colors: [Color(red: 0.06, green: 0.12, blue: 0.11),
                                    Color(red: 0.10, green: 0.22, blue: 0.18)],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()

            VStack(spacing: 24) {
                Image(systemName: "lungs.fill")
                    .font(.system(size: 46))
                    .foregroundStyle(.mint)
                    .padding(.top, 30)

                Text("SMOKE-FREE")
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .tracking(3)
                    .foregroundStyle(.mint)

                Text(CheckInStore.checkedInToday ? "You showed up today." : "One day at a time.")
                    .font(.system(size: 29, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.white)

                VStack(spacing: 5) {
                    Text("\(CheckInStore.streak)")
                        .font(.system(size: 64, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)
                    Text("DAY STREAK")
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .tracking(2)
                        .foregroundStyle(.mint)
                }
                .padding(.vertical, 22)
                .frame(maxWidth: .infinity)
                .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 24))

                Button {
                    _ = CheckInStore.checkInToday()
                    refresh.toggle()
                } label: {
                    Label(CheckInStore.checkedInToday ? "Checked in for today" : "I DIDN'T SMOKE TODAY",
                          systemImage: CheckInStore.checkedInToday ? "checkmark.circle.fill" : "checkmark.circle")
                        .font(.system(size: 16, weight: .bold, design: .rounded))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 18)
                        .background(CheckInStore.checkedInToday ? Color.white.opacity(0.14) : Color.mint,
                                    in: RoundedRectangle(cornerRadius: 18))
                        .foregroundStyle(CheckInStore.checkedInToday ? .white : Color.black)
                }
                .disabled(CheckInStore.checkedInToday)

                Text("No guilt. No perfection. If today is hard, just focus on the next smoke-free choice.")
                    .font(.system(size: 14, design: .rounded))
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.white.opacity(0.72))
                    .padding(.horizontal, 8)

                Spacer()
                Text("Your progress belongs to you.")
                    .font(.footnote)
                    .foregroundStyle(.white.opacity(0.45))
                    .padding(.bottom, 18)
            }
            .padding(24)
        }
        .preferredColorScheme(.dark)
    }
}
