import WidgetKit
import SwiftUI
import AppIntents

struct SmokeFreeEntry: TimelineEntry {
    let date: Date
    let checkedIn: Bool
    let streak: Int
}

struct SmokeFreeProvider: TimelineProvider {
    func placeholder(in context: Context) -> SmokeFreeEntry {
        SmokeFreeEntry(date: Date(), checkedIn: false, streak: 3)
    }

    func getSnapshot(in context: Context, completion: @escaping (SmokeFreeEntry) -> Void) {
        completion(currentEntry())
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<SmokeFreeEntry>) -> Void) {
        let entry = currentEntry()
        let nextRefresh = Calendar.current.date(byAdding: .hour, value: 1, to: Date()) ?? Date().addingTimeInterval(3600)
        completion(Timeline(entries: [entry], policy: .after(nextRefresh)))
    }

    private func currentEntry() -> SmokeFreeEntry {
        SmokeFreeEntry(date: Date(), checkedIn: CheckInStore.checkedInToday, streak: CheckInStore.streak)
    }
}

struct SmokeFreeWidgetView: View {
    let entry: SmokeFreeEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "lungs.fill").foregroundStyle(.mint)
                Text("SMOKE-FREE").font(.caption2.bold()).tracking(1.2)
                Spacer()
            }
            Text("\(entry.streak)")
                .font(.system(size: 42, weight: .heavy, design: .rounded))
            Text(entry.streak == 1 ? "day in a row" : "days in a row")
                .font(.caption)
                .foregroundStyle(.secondary)
            Spacer(minLength: 0)
            if entry.checkedIn {
                Label("Checked in today", systemImage: "checkmark.circle.fill")
                    .font(.caption.bold())
                    .foregroundStyle(.mint)
            } else {
                Button(intent: SmokeFreeCheckInIntent()) {
                    Label("I didn't smoke", systemImage: "checkmark.circle.fill")
                        .font(.caption.bold())
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(.mint)
            }
        }
        .padding()
        .containerBackground(.background, for: .widget)
    }
}

struct SmokeFreeCheckInIntent: AppIntent {
    static var title: LocalizedStringResource = "Check in smoke-free"
    static var description = IntentDescription("Mark today as a smoke-free day.")
    static var openAppWhenRun = false

    func perform() async throws -> some IntentResult {
        _ = CheckInStore.checkInToday()
        return .result()
    }
}

@main
struct SmokeFreeWidget: Widget {
    let kind = "SmokeFreeWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: SmokeFreeProvider()) { entry in
            SmokeFreeWidgetView(entry: entry)
        }
        .configurationDisplayName("Smoke-Free Check-In")
        .description("Tap once each day to log a smoke-free day.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}
