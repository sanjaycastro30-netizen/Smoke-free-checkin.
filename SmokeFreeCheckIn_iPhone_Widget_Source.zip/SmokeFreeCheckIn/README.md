# Smoke-Free Check-In (iPhone Widget starter)

A simple SwiftUI app plus an interactive iOS Home Screen widget. Tap **I didn't smoke** once per day; it records the date and shows your current consecutive-day streak.

## What you need
- A Mac with a recent version of Xcode (the widget button uses iOS 17+ App Intents).
- An iPhone running iOS 17 or later.
- Your Apple ID for installing the app on your own phone.

**Important:** You can't install a native iPhone widget by pasting code into the iPhone. The app and widget extension must be built and signed in Xcode. This folder contains the source files, not a pre-signed App Store app.

## Build it in Xcode
1. Open Xcode and create a new **iOS App** project named `SmokeFreeCheckIn`, using **SwiftUI**.
2. Set the deployment target to **iOS 17.0** or newer.
3. Add `CheckInStore.swift` and `CheckInView.swift` to the main app target. Replace the generated app file with `SmokeFreeCheckInApp.swift` (or copy its `@main` body into your generated app file; there must be only one `@main` app).
4. In the project menu choose **File → New → Target… → Widget Extension**. Name it `SmokeFreeWidget`. Enable the option to include a configuration intent only if Xcode asks; this sample uses an App Intent directly.
5. Add `SmokeFreeWidget.swift` and `CheckInStore.swift` to the **widget extension** target too. Ensure `CheckInStore.swift` is included in both targets.
6. In the project settings, select the main app target → **Signing & Capabilities** → **+ Capability** → **App Groups**. Add an App Group, for example `group.com.yourname.SmokeFreeCheckIn`.
7. Add the exact same App Group to the widget extension target. In `CheckInStore.swift`, change `group.com.example.SmokeFreeCheckIn` to your chosen identifier.
8. Select your iPhone as the run destination, connect it (or use wireless debugging), select your Personal Team under Signing, then press **Run**.
9. Open the app once. On the iPhone Home Screen, long-press an empty area → **Edit** → **Add Widget** → search for **Smoke-Free Check-In** → add the small or medium widget.

## Notes
- The streak is based on consecutive calendar days where you checked in. Missing a day resets the current streak; previous check-ins remain saved.
- The widget button is interactive on iOS 17+. Widget updates can take a short moment to refresh.
- This is a starter project source bundle, not a medical product. If you smoke one day, you haven't failed—check in again when you're ready and keep going.
