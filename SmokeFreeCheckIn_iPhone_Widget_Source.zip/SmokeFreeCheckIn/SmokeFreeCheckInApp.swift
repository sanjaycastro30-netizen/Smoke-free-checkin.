import SwiftUI

@main
struct SmokeFreeCheckInApp: App {
    var body: some Scene {
        WindowGroup {
            CheckInView()
        }
    }
}
